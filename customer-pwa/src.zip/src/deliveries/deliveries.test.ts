import assert from 'node:assert/strict';
import test from 'node:test';
import {
  ACTIVE_LIST_STATUSES,
  deliveryCanSearchAgain,
  deliveryCardAddress,
  deliveryCardStatusLabel,
  deliveryContentKind,
  deliveryDistanceLabel,
  deliveryGroup,
  cancelledDeliveryCopy,
  deliveryOutcomeSupport,
  deliveryOutcomeTitle,
  deliveryWhenLabel,
  moneyLabel,
  paymentBadge,
  readCustomerDeliveryPage,
  shortDeliveryReference,
  sortDeliveries,
  type CustomerDelivery,
} from './rules.ts';

function delivery(overrides: Partial<CustomerDelivery> = {}): CustomerDelivery {
  return {
    id: 'delivery-1',
    status: 'SEARCHING',
    createdAt: '2026-11-13T08:00:00.000Z',
    pickupAddress: '12 Samora Machel Avenue, Harare, Zimbabwe',
    dropoffAddress: '4 Jason Moyo Street, Harare, Zimbabwe',
    serviceClass: null,
    deliverBy: null,
    currency: 'USD',
    suggestedPrice: '3.00',
    offeredPrice: '4.50',
    distanceMeters: 1200,
    parcelDescription: 'Parcel',
    openBidCount: 0,
    ...overrides,
  };
}

test('active and history use the native status groups', () => {
  assert.equal(deliveryGroup('SEARCHING'), 'active');
  assert.equal(deliveryGroup('DELIVERED'), 'history');
  assert.equal(deliveryGroup('CANCELLED'), 'history');
  assert.ok(ACTIVE_LIST_STATUSES.includes('NO_RIDER_FOUND'));
  assert.equal(ACTIVE_LIST_STATUSES.includes('DELIVERED'), false);
});

test('card status, search again, content, and address follow the native rules', () => {
  assert.equal(deliveryCardStatusLabel(delivery({ status: 'CREATED', serviceClass: 'FLEXIBLE' })), 'Waiting for offers');
  assert.equal(deliveryCardStatusLabel(delivery({ status: 'CREATED', serviceClass: 'EXPRESS', openBidCount: 2 })), '2 offers received');
  assert.equal(deliveryCardStatusLabel(delivery({ status: 'COLLECTED' })), 'In transit');
  assert.equal(deliveryCanSearchAgain(delivery({ status: 'NO_RIDER_FOUND', serviceClass: 'EXPRESS', deliverBy: null })), true);
  assert.equal(deliveryCanSearchAgain(delivery({ status: 'NO_RIDER_FOUND', serviceClass: null })), false);
  assert.equal(deliveryContentKind('documents'), 'document');
  assert.equal(deliveryContentKind('food'), 'food');
  assert.equal(deliveryCardAddress('12 Samora Machel Avenue, Harare, Zimbabwe'), '12 Samora Machel Ave');
  assert.equal(shortDeliveryReference('delivery-1'), '#VERY1');
  assert.equal(deliveryOutcomeTitle('PICKED_UP'), 'In transit');
  assert.equal(deliveryOutcomeTitle('CANCELLED'), 'Cancelled');
  assert.match(deliveryOutcomeSupport('NO_RIDER_FOUND'), /No rider was available/);
  assert.equal(deliveryDistanceLabel(850), '850 m');
  assert.equal(deliveryDistanceLabel(1200), '1.2 km');
  assert.equal(moneyLabel('USD', '4.50'), 'USD 4.50');
  assert.equal(moneyLabel('USD', '20.00'), 'USD 20');
  assert.equal(moneyLabel('USD', '20.05'), 'USD 20.05');
  assert.equal(moneyLabel('ZWG', '21.00'), 'ZiG 21');
  assert.equal(moneyLabel('ZWG', '4.50'), 'ZiG 4.50');
  assert.equal(paymentBadge('CASH'), 'Cash');
  assert.equal(paymentBadge('ECOCASH'), 'EcoCash');
  assert.equal(paymentBadge(null), null);
  assert.equal(paymentBadge('ZIPIT'), null);
  assert.equal(paymentBadge(''), null);
  const when = deliveryWhenLabel('2026-11-13T08:05:00.000Z');
  assert.match(when, /13 Nov 2026 • \d{2}:\d{2}/);
});

test('cancelled deliveries name the actor and only rebook before pickup', () => {
  const rider = cancelledDeliveryCopy({ actor: 'RIDER', reason: 'BREAKDOWN', afterPickup: false });
  assert.equal(rider.title, 'Rider cancelled');
  assert.equal(rider.support, 'Your rider cancelled this delivery. To find another rider, create a new delivery request.');
  assert.equal(rider.bookAgain, true);
  assert.equal(rider.contactSupport, false);
  const collected = cancelledDeliveryCopy({ actor: 'RIDER', reason: 'BREAKDOWN', afterPickup: true });
  assert.match(collected.support, /after collecting the parcel/);
  assert.match(collected.support, /Contact support/);
  assert.equal(collected.bookAgain, false);
  assert.equal(collected.contactSupport, true);
  const customer = cancelledDeliveryCopy({ actor: 'CUSTOMER', reason: null, afterPickup: false });
  assert.equal(customer.title, 'Cancelled');
  assert.equal(customer.support, 'This delivery was cancelled.');
  assert.equal(customer.bookAgain, false);
  assert.equal(deliveryGroup('CANCELLED'), 'history');
});

test('deliveries sort by newest date and read the list payload', () => {
  const older = delivery({ id: 'a', createdAt: '2026-11-12T08:00:00.000Z' });
  const newer = delivery({ id: 'b', createdAt: '2026-11-13T08:00:00.000Z' });
  assert.deepEqual(sortDeliveries([older, newer], 'newest').map((item) => item.id), ['b', 'a']);
  const page = readCustomerDeliveryPage({
    data: [{
      id: 'delivery-1',
      reference: 'R-1',
      status: 'SEARCHING',
      createdAt: '2026-11-13T08:00:00.000Z',
      pickup: { address: 'Pickup' },
      dropoff: { address: 'Dropoff' },
      currency: 'USD',
      suggestedPrice: '3.00',
      offeredPrice: null,
      distanceMeters: 10,
      parcel: { description: 'Food' },
      openBidCount: 0,
    }],
    pagination: { page: 1, totalPages: 2 },
  });
  assert.equal(page.deliveries[0]?.parcelDescription, 'Food');
  assert.equal(page.totalPages, 2);
  assert.throws(() => readCustomerDeliveryPage({ data: [], pagination: { page: 1 } }), /unavailable/);
});
