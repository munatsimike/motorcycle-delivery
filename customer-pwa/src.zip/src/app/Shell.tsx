import { useLayoutEffect, useRef, type ReactNode } from 'react';
import { NavLink, Outlet, useLocation } from 'react-router-dom';

export function Shell() {
  const { pathname } = useLocation();
  const onDeliveries = pathname === '/deliveries';
  const mainRef = useRef<HTMLDivElement>(null);
  useLayoutEffect(() => {
    const node = mainRef.current;
    if (!node || document.documentElement.classList.contains('is-page-transition')) return;
    node.classList.remove('is-entering');
    void node.offsetWidth;
    node.classList.add('is-entering');
  }, [pathname]);
  return (
    <div className={onDeliveries ? 'shell shell-deliveries' : 'shell'}>
      <div ref={mainRef} className="shell-main page-stage">
        <Outlet />
      </div>
      <nav className="shell-nav" aria-label="Customer">
        <TabLink to="/home" label="Home" end>
          {(active) => <HomeIcon filled={active} />}
        </TabLink>
        <TabLink to="/deliveries" label="Deliveries" end>
          {(active) => <PackageIcon filled={active} />}
        </TabLink>
        <TabLink to="/more" label="More" end>
          {(active) => <MoreIcon filled={active} />}
        </TabLink>
      </nav>
    </div>
  );
}

function TabLink({
  to,
  label,
  end = false,
  children,
}: {
  to: string;
  label: string;
  end?: boolean;
  children: (active: boolean) => ReactNode;
}) {
  return (
    <NavLink to={to} end={end} className="shell-tab">
      {({ isActive }) => (
        <>
          <span className="shell-tab-icon">{children(isActive)}</span>
          {label}
        </>
      )}
    </NavLink>
  );
}

function HomeIcon({ filled }: { filled: boolean }) {
  return (
    <svg viewBox="0 0 24 24" aria-hidden="true">
      {filled ? (
        <path d="M12 3.2 3 11h2v9h5.2v-5.4h3.6V20H19v-9h2L12 3.2Z" />
      ) : (
        <path d="M12 5.69 17 10.19V18h-2v-6H9v6H7v-7.81L12 5.69M12 3 2 12h3v8h6v-6h2v6h6v-8h3L12 3Z" />
      )}
    </svg>
  );
}

function PackageIcon({ filled }: { filled: boolean }) {
  return (
    <svg viewBox="0 0 24 24" aria-hidden="true">
      {filled ? (
        <path d="M12 2.2 3.4 7.05v9.9L12 21.8l8.6-4.85v-9.9L12 2.2Z" />
      ) : (
        <path d="M12 3.2 4.2 7.2v9.6L12 20.8l7.8-4V7.2L12 3.2Zm0 1.7 5.8 3-5.8 3-5.8-3 5.8-3ZM5.7 9.4l5.3 2.7v6.2l-5.3-2.7V9.4Zm7.3 8.9v-6.2l5.3-2.7v6.2l-5.3 2.7Z" />
      )}
    </svg>
  );
}

function MoreIcon({ filled }: { filled: boolean }) {
  return (
    <svg viewBox="0 0 24 24" aria-hidden="true">
      <path
        fill="currentColor"
        d="M6 10a2 2 0 1 1 0 4 2 2 0 0 1 0-4m6 0a2 2 0 1 1 0 4 2 2 0 0 1 0-4m6 0a2 2 0 1 1 0 4 2 2 0 0 1 0-4"
        opacity={filled ? 1 : 0.7}
      />
    </svg>
  );
}
