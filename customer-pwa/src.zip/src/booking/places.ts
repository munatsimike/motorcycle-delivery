export type PlaceSuggestion = {
  label: string;
  latitude: string;
  longitude: string;
  exact: boolean;
  placeId?: string;
  sessionToken?: string;
};

export type ResolvedPlace = {
  label: string;
  latitude: string;
  longitude: string;
  suburb?: string;
  locality?: string;
};

export type ResolvedLocation = {
  label: string;
  latitude: string;
  longitude: string;
  provider: 'google_places' | 'device';
  placeId: string | null;
  precision: 'exact' | 'area' | 'unverified';
};

export type ManualAddressResolution =
  | { status: 'resolved'; location: ResolvedLocation }
  | { status: 'confirm-pin'; location: ResolvedLocation }
  | { status: 'choose-area'; areas: PlaceSuggestion[] }
  | { status: 'unresolved' };

export function createPlaceSessionToken(): string {
  const bytes = new Uint8Array(16);
  globalThis.crypto.getRandomValues(bytes);
  bytes[6] = (bytes[6] & 0x0f) | 0x40;
  bytes[8] = (bytes[8] & 0x3f) | 0x80;
  const hex = Array.from(bytes, (byte) => byte.toString(16).padStart(2, '0')).join('');
  return `${hex.slice(0, 8)}-${hex.slice(8, 12)}-${hex.slice(12, 16)}-${hex.slice(16, 20)}-${hex.slice(20)}`;
}

export function readPlaceSuggestions(value: unknown): PlaceSuggestion[] {
  if (!isRecord(value) || !Array.isArray(value.suggestions)) throw new Error('Address suggestions are unavailable.');
  const suggestions: PlaceSuggestion[] = [];
  for (const item of value.suggestions) {
    if (!isRecord(item) || typeof item.label !== 'string' || !item.label.trim() || typeof item.exact !== 'boolean') continue;
    const placeId = typeof item.placeId === 'string' && item.placeId.trim() ? item.placeId.trim() : undefined;
    const latitude = coordinate(item.latitude, 90);
    const longitude = coordinate(item.longitude, 180);
    if ((latitude === null || longitude === null) && !placeId) continue;
    suggestions.push({
      label: suggestionAddress(item.label.trim()),
      latitude: latitude === null ? '' : latitude.toFixed(7),
      longitude: longitude === null ? '' : longitude.toFixed(7),
      exact: item.exact,
      placeId,
    });
    if (suggestions.length === 10) break;
  }
  return suggestions;
}

export function readResolvedPlace(value: unknown): ResolvedPlace {
  if (!isRecord(value) || typeof value.label !== 'string' || !value.label.trim()) {
    throw new Error('Address suggestions are unavailable.');
  }
  const latitude = coordinate(value.latitude, 90);
  const longitude = coordinate(value.longitude, 180);
  if (latitude === null || longitude === null) throw new Error('Address suggestions are unavailable.');
  const suburb = typeof value.suburb === 'string' && value.suburb.trim() ? value.suburb.trim() : undefined;
  const locality = typeof value.locality === 'string' && value.locality.trim() ? value.locality.trim() : undefined;
  return {
    label: suggestionAddress(value.label.trim()),
    latitude: latitude.toFixed(7),
    longitude: longitude.toFixed(7),
    ...(suburb ? { suburb } : {}),
    ...(locality ? { locality } : {}),
  };
}

export function selectedAddressLabel(suggestionLabel: string, place: { label?: string; suburb?: string; locality?: string }): string {
  const formatted = suggestionAddress(place.label?.trim() || suggestionLabel);
  const suburb = place.suburb?.trim() ?? '';
  const parts = addressParts(formatted);
  if (!suburb) return formatted || suggestionAddress(suggestionLabel);
  if (parts.length === 0 || parts[0].toLowerCase() === suburb.toLowerCase()) return suburb;
  return `${parts[0]}, ${suburb}`;
}

export function resolveManualAddress(
  typedAddress: string,
  suggestions: PlaceSuggestion[],
  devicePoint: { latitude: string; longitude: string } | null,
): ManualAddressResolution {
  const exact = suggestions.find((suggestion) => suggestion.exact && suggestion.placeId);
  if (exact?.placeId) {
    return {
      status: 'resolved',
      location: {
        label: withoutCountry(exact.label),
        latitude: exact.latitude,
        longitude: exact.longitude,
        provider: 'google_places',
        placeId: exact.placeId,
        precision: 'exact',
      },
    };
  }
  if (devicePoint) {
    return {
      status: 'confirm-pin',
      location: {
        label: withoutCountry(typedAddress),
        latitude: devicePoint.latitude,
        longitude: devicePoint.longitude,
        provider: 'device',
        placeId: null,
        precision: 'unverified',
      },
    };
  }
  const areas = suggestions.filter((suggestion) => !suggestion.exact);
  if (areas.length > 0) return { status: 'choose-area', areas };
  return { status: 'unresolved' };
}

export function manualGeocodeAccepts(typedAddress: string, formattedAddress: string): boolean {
  const tokens = typedAddress.toLowerCase().replace(/[^a-z0-9]+/g, ' ').split(' ').filter((token) => token.length >= 3);
  if (tokens.length === 0) return false;
  const formatted = formattedAddress.toLowerCase();
  return tokens.every((token) => formatted.includes(token));
}

export function confirmMapPin(area: PlaceSuggestion): ResolvedLocation {
  return {
    label: withoutCountry(area.label),
    latitude: area.latitude,
    longitude: area.longitude,
    provider: 'google_places',
    placeId: area.placeId ?? null,
    precision: area.exact ? 'exact' : 'area',
  };
}

export function acceptSearchResult<T>(started: number, current: number, value: T): T | null {
  return started === current ? value : null;
}

const ZIMBABWE_EXTENT: ReadonlyArray<readonly [number, number]> = [
  [25.24, -17.78],
  [25.24, -19.30],
  [26.50, -21.20],
  [28.20, -22.40],
  [31.20, -22.42],
  [32.95, -21.60],
  [33.07, -18.20],
  [32.75, -16.05],
  [30.40, -15.61],
  [28.20, -15.70],
  [26.40, -17.10],
];

export const MAX_PICKUP_FIX_AGE_MS = 120_000;

export type PickupLocateFailure = 'denied' | 'timeout' | 'unavailable';

export function geolocationFailure(code: number): PickupLocateFailure {
  if (code === 1) return 'denied';
  if (code === 3) return 'timeout';
  return 'unavailable';
}

export function canRetryLocation(failure: PickupLocateFailure): boolean {
  return failure !== 'denied';
}

export function reverseGeocodeOutcome(
  status: string,
  results: ReadonlyArray<{ address_components?: readonly GeocoderComponent[] | null; formatted_address?: string | null }> | null | undefined,
): { ok: true; address: { display: string; fullAddress: string; needsStreet: boolean } } | { ok: false; reason: 'geocode-failed' | 'geocode-empty'; status: string } {
  const safeStatus = GEOCODE_DIAGNOSTICS.has(status) ? status : 'UNKNOWN_ERROR';
  if (safeStatus !== 'OK') return { ok: false, reason: 'geocode-failed', status: safeStatus };
  const address = readReverseGeocode(results);
  if (!address?.display) return { ok: false, reason: 'geocode-empty', status: 'OK' };
  return { ok: true, address };
}

export function readReverseGeocodeBody(value: unknown): { status: string; results: Array<{ formatted_address: string; address_components: GeocoderComponent[] }> } {
  if (!isRecord(value) || typeof value.status !== 'string') return { status: 'UNAVAILABLE', results: [] };
  const results: Array<{ formatted_address: string; address_components: GeocoderComponent[] }> = [];
  if (Array.isArray(value.results)) {
    for (const item of value.results) {
      if (!isRecord(item)) continue;
      const components: GeocoderComponent[] = [];
      if (Array.isArray(item.address_components)) {
        for (const component of item.address_components) {
          if (!isRecord(component)) continue;
          const types = Array.isArray(component.types) ? component.types.filter((type): type is string => typeof type === 'string') : [];
          components.push({
            long_name: typeof component.long_name === 'string' ? component.long_name : '',
            short_name: typeof component.short_name === 'string' ? component.short_name : '',
            types,
          });
        }
      }
      const formatted = typeof item.formatted_address === 'string' ? item.formatted_address : '';
      if (!formatted && components.length === 0) continue;
      results.push({ formatted_address: formatted, address_components: components });
    }
  }
  return { status: value.status, results };
}

export type ServiceAreaMode = 'worldwide' | 'zimbabwe';

// Worldwide is the temporary testing default. Set this back to 'zimbabwe' to restore the polygon.
export const SERVICE_AREA_MODE: ServiceAreaMode = 'worldwide';

function coordinateInsideServiceArea(longitude: number, latitude: number): boolean {
  if (!Number.isFinite(latitude) || latitude < -90 || latitude > 90) return false;
  if (!Number.isFinite(longitude) || longitude < -180 || longitude > 180) return false;
  if (SERVICE_AREA_MODE === 'worldwide') return true;
  return pointInRing(longitude, latitude, ZIMBABWE_EXTENT);
}

export type PickupAutofillRejection = 'denied' | 'invalid-accuracy' | 'stale-location' | 'outside-area';

const LOCATE_DIAGNOSTICS = new Set([
  'denied',
  'timeout',
  'unavailable',
  'stale-location',
  'invalid-accuracy',
  'outside-area',
  'geocode-failed',
  'geocode-empty',
  'kept-manual',
  'applied',
]);

const GEOCODE_DIAGNOSTICS = new Set(['OK', 'ZERO_RESULTS', 'OVER_QUERY_LIMIT', 'REQUEST_DENIED', 'INVALID_REQUEST', 'UNKNOWN_ERROR', 'UNAVAILABLE']);

export function pickupLocateDiagnostic(reason: string): string {
  const parts = reason.split(':');
  const name = parts[0] ?? '';
  const status = parts[1] ?? '';
  if (parts.length > 2 || !LOCATE_DIAGNOSTICS.has(name)) return 'unknown';
  if (!status) return name;
  return GEOCODE_DIAGNOSTICS.has(status) ? `${name}:${status}` : name;
}

export function pickupAutofillRejection(input: {
  permission: 'granted' | 'prompt' | 'denied' | 'unknown';
  latitude: number;
  longitude: number;
  accuracyMetres: number | null;
  capturedAt: number;
  now: number;
}): PickupAutofillRejection | null {
  if (input.permission !== 'granted') return 'denied';
  if (input.accuracyMetres != null && (!Number.isFinite(input.accuracyMetres) || input.accuracyMetres < 0)) return 'invalid-accuracy';
  if (input.now - input.capturedAt > MAX_PICKUP_FIX_AGE_MS) return 'stale-location';
  if (!coordinateInsideServiceArea(input.longitude, input.latitude)) return 'outside-area';
  return null;
}

export function pickupAutofillFix(input: {
  permission: 'granted' | 'prompt' | 'denied' | 'unknown';
  latitude: number;
  longitude: number;
  accuracyMetres: number | null;
  capturedAt: number;
  now: number;
}): { latitude: string; longitude: string } | null {
  if (pickupAutofillRejection(input)) return null;
  return { latitude: String(input.latitude), longitude: String(input.longitude) };
}

export type GeocoderComponent = { long_name?: string; short_name?: string; types?: string[] };

export function readGeocodedAddress(
  components: readonly GeocoderComponent[] | null | undefined,
  formatted?: string | null,
): { display: string; fullAddress: string; needsStreet: boolean } | null {
  const part = (type: string) => components?.find((item) => item.types?.includes(type))?.long_name?.trim() ?? '';
  const country = part('country');
  const countryCode = components?.find((item) => item.types?.includes('country'))?.short_name?.trim().toLowerCase() ?? '';
  const city = part('locality') || part('administrative_area_level_1');
  const suburb = part('sublocality') || part('sublocality_level_1') || part('neighborhood');
  const street = [part('street_number'), part('route')].filter(Boolean).join(' ');
  const zimbabwe = countryCode === 'zw' || country.toLowerCase() === 'zimbabwe';
  const composed = uniqueAddress(street ? (zimbabwe ? [street, suburb] : [street, suburb, city]) : [suburb, city]);
  const formattedLabel = readableFormattedAddress(formatted, country);
  const display = street ? composed : (formattedLabel || composed);
  const fullAddress = uniqueAddress([street, suburb, city, country]) || formatted?.trim() || display;
  if (!display && !fullAddress) return null;
  return { display, fullAddress, needsStreet: display.length === 0 };
}

export function readReverseGeocode(
  results: ReadonlyArray<{ address_components?: readonly GeocoderComponent[] | null; formatted_address?: string | null }> | null | undefined,
): { display: string; fullAddress: string; needsStreet: boolean } | null {
  let fallback: { display: string; fullAddress: string; needsStreet: boolean } | null = null;
  for (const result of results ?? []) {
    const read = readGeocodedAddress(result.address_components, result.formatted_address);
    if (!read?.display) continue;
    const hasStreet = result.address_components?.some((component) => component.types?.includes('route') || component.types?.includes('street_number')) === true;
    if (hasStreet) return read;
    fallback ??= read;
  }
  return fallback;
}

function readableFormattedAddress(formatted: string | null | undefined, country: string): string {
  const parts = formatted?.split(',').map((part) => part.trim()).filter((part) => part.length > 0) ?? [];
  const last = parts[parts.length - 1]?.toLowerCase() ?? '';
  if (parts.length > 1 && (last === country.trim().toLowerCase() || last === 'zimbabwe')) parts.pop();
  return parts.join(', ');
}

function uniqueAddress(parts: string[]): string {
  const seen = new Set<string>();
  return parts.filter((part) => {
    const key = part.trim().toLowerCase();
    if (!key || seen.has(key)) return false;
    seen.add(key);
    return true;
  }).join(', ');
}

export function decideAddressAutofill(userEdited: boolean, result: { display: string; fullAddress: string; needsStreet: boolean } | null) {
  if (userEdited || !result) return { status: 'ignore' as const, display: '', fullAddress: '' };
  if (result.needsStreet || !result.display) return { status: 'needs-street' as const, display: '', fullAddress: result.fullAddress };
  return { status: 'apply' as const, display: result.display, fullAddress: result.fullAddress };
}

function withoutCountry(label: string): string {
  return suggestionAddress(label);
}

export function suggestionAddress(label: string): string {
  let parts = addressParts(label);
  if (parts.length > 1 && parts[parts.length - 1]?.toLowerCase() === 'zimbabwe') parts.pop();
  if (parts.length >= 3) parts = [parts[0], localityName(parts[1])];
  else if (parts.length === 2) parts = [parts[0], localityName(parts[1])];
  return parts.filter((part) => part.length > 0).join(', ');
}

function localityName(part: string): string {
  const words = part.split(/\s+/).filter((word) => word.length > 0);
  let index = 0;
  while (index < words.length - 1 && /\d/.test(words[index])) index += 1;
  while (index < words.length - 1 && /^[A-Z]{1,3}$/.test(words[index])) index += 1;
  return words.slice(index).join(' ');
}

function addressParts(label: string): string[] {
  return label.split(',').map((part) => part.trim()).filter((part) => part.length > 0);
}

function coordinate(value: unknown, limit: number): number | null {
  const numeric = typeof value === 'number' ? value : typeof value === 'string' ? Number(value) : Number.NaN;
  if (!Number.isFinite(numeric) || numeric < -limit || numeric > limit) return null;
  return numeric;
}

function pointInRing(longitude: number, latitude: number, ring: ReadonlyArray<readonly [number, number]>): boolean {
  let inside = false;
  for (let index = 0, previous = ring.length - 1; index < ring.length; previous = index++) {
    const currentPoint = ring[index];
    const previousPoint = ring[previous];
    if (!currentPoint || !previousPoint) continue;
    const crossesLatitude = (currentPoint[1] > latitude) !== (previousPoint[1] > latitude);
    if (!crossesLatitude) continue;
    const edgeLongitude = ((previousPoint[0] - currentPoint[0]) * (latitude - currentPoint[1])) / (previousPoint[1] - currentPoint[1]) + currentPoint[0];
    if (longitude < edgeLongitude) inside = !inside;
  }
  return inside;
}

function isRecord(value: unknown): value is Record<string, unknown> {
  return typeof value === 'object' && value !== null && !Array.isArray(value);
}
