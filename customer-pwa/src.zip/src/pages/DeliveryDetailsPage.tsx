import { useEffect, useRef, useState, type RefObject } from 'react';
import { Link, useNavigate, useParams } from 'react-router-dom';
import { useSession } from '../auth/sessionContext';
import { Button } from '../components/Button';
import { BackIcon } from '../components/icons';
import { ButtonSpinner } from '../components/ButtonSpinner';
import { modalActionFeedback, pageActionFeedback, searchAgainControl } from '../components/buttonState';
import { deliveryCancelledToast, riderConfirmedToast, showSuccessToast } from '../components/successToast';
import { ErrorMessage } from '../components/ErrorMessage';
import { TopSpinner } from '../components/TopSpinner';
import { ContentMark, DeliveryLabels } from '../components/DeliveryLabels';
import { acceptOffer, adjustOffer, cancelDelivery, deliveryErrorMessage, dismissOffer, loadDelivery, loadDeliveryRoute, loadOffers, searchForRider } from '../deliveries/api';
import { offerResponseSeconds, offerResponseLabel, routeCooldownSeconds } from '../deliveries/offerResponse';
import { PaymentBadge } from '../deliveries/PaymentBadge';
import { RiderPhoto } from '../deliveries/RiderPhoto';
import { TrackingMap } from '../deliveries/TrackingMap';
import { fetchNearbyRiders } from '../home/nearbyApi';
import { filterValidNearbyRiderPoints, NEARBY_MARKER_PRUNE_MS, type NearbyRiderMapPoint } from '../home/nearby';
import { beginPageTransition } from '../motion/pageTransition';
import { motionClass, usePresence } from '../motion/usePresence';
import {
  TRACKING_POLL_MS,
  activeCustomerBids,
  activeOfferCountLabel,
  customerOfferForBooking,
  deliveryActions,
  deliveryScreen,
  detailViewState,
  acceptanceKeyFor,
  bidCanAccept,
  clearAcceptanceKey,
  createAcceptanceGate,
  duplicateAcceptanceNotice,
  keepsRiderLocation,
  keepsAcceptanceKey,
  offerFieldText,
  offersMissingSince,
  offerMapMarkers,
  offerRiderName,
  pickupEtaLabel,
  riderBikeLine,
  riderClassLabel,
  riderRatingLine,
  riderDialUrl,
  riderMarkerForMap,
  riderWhatsAppUrl,
  activeStopStraightLineMetres,
  pickupDistanceTag,
  withinArrival,
  shouldPollDelivery,
  showsCompletedRoute,
  showsDeliveredDestination,
  statusBandCopy,
  showsRiderOffers,
  sortRiderOffers,
  trackingHeadline,
  trackingSubtitle,
  customerListStatusLabel,
  trackingMapView,
  withoutBidMapPoints,
  type CustomerBid,
  type CustomerDeliveryDetail,
  type OfferSort,
  type RoutePoint,
} from '../deliveries/tracking';
import { bookingDraftFromDelivery } from '../booking/draft';
import {
  cancelledDeliveryCopy,
  deliveryCardAddress,
  deliveryContentKind,
  deliveryDistanceLabel,
  deliveryOutcomeSupport,
  deliveryOutcomeTitle,
  deliveryStatusTone,
  deliveryWhenLabel,
  moneyLabel,
  outcomeShowsRider,
  shortDeliveryReference,
} from '../deliveries/rules';

export function DeliveryDetailsPage() {
  const { id = '' } = useParams();
  const navigate = useNavigate();
  const { accessToken } = useSession();
  const [delivery, setDelivery] = useState<CustomerDeliveryDetail | null>(null);
  const [offers, setOffers] = useState<CustomerBid[]>([]);
  const [isLoading, setIsLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [now, setNow] = useState(() => Date.now());
  const [parcelOpen, setParcelOpen] = useState(false);
  const [confirm, setConfirm] = useState<null | 'cancel' | 'delete' | CustomerBid>(null);
  const [busy, setBusy] = useState(false);
  const [actionError, setActionError] = useState<string | null>(null);
  const [offerSort, setOfferSort] = useState<OfferSort>('price');
  const [sortOpen, setSortOpen] = useState(false);
  const [priceOpen, setPriceOpen] = useState(false);
  const [priceText, setPriceText] = useState('');
  const [priceError, setPriceError] = useState<string | null>(null);
  const [confirmError, setConfirmError] = useState<string | null>(null);
  const [decline, setDecline] = useState<CustomerBid | null>(null);
  const [declineError, setDeclineError] = useState<string | null>(null);
  const [searching, setSearching] = useState(false);
  const [offersLoaded, setOffersLoaded] = useState(false);
  const [offersError, setOffersError] = useState<string | null>(null);
  const [offerNotice, setOfferNotice] = useState<string | null>(null);
  const [nearby, setNearby] = useState<NearbyRiderMapPoint[]>([]);
  const [routeLine, setRouteLine] = useState<RoutePoint[]>([]);
  const [token, setToken] = useState<string | null>(null);
  const [attempt, setAttempt] = useState(0);
  const [detailsRetrying, setDetailsRetrying] = useState(false);
  const [offersRetrying, setOffersRetrying] = useState(false);
  const retryHold = useRef<'details' | 'offers' | null>(null);
  const latest = useRef<CustomerDeliveryDetail | null>(null);
  const seenOffers = useRef<string[]>([]);
  const dismissedOffers = useRef(new Set<string>());
  const dismissedDeliveryId = useRef('');
  const accepting = useRef(createAcceptanceGate());
  const busyRef = useRef(false);
  const cancelTriggerRef = useRef<HTMLButtonElement>(null);
  const keepRequestRef = useRef<HTMLButtonElement>(null);
  const cancelDialogRef = useRef<HTMLDivElement>(null);
  const cancelHistory = useRef(false);
  const cancelLeaving = useRef(false);
  const chooseTriggerRef = useRef<HTMLButtonElement>(null);
  const keepComparingRef = useRef<HTMLButtonElement>(null);
  const riderDialogRef = useRef<HTMLDivElement>(null);
  const riderHistory = useRef(false);
  const declineTriggerRef = useRef<HTMLButtonElement>(null);
  const keepOfferRef = useRef<HTMLButtonElement>(null);
  const declineDialogRef = useRef<HTMLDivElement>(null);
  const declineHistory = useRef(false);
  latest.current = delivery;

  useEffect(() => {
    if (confirm !== 'cancel') {
      if (cancelHistory.current) {
        cancelHistory.current = false;
        cancelTriggerRef.current?.focus();
        if (window.history.state?.cancelDeliveryDialog === true) window.history.back();
      }
      return undefined;
    }
    keepRequestRef.current?.focus();
    if (!cancelHistory.current) {
      window.history.pushState({ cancelDeliveryDialog: true }, '');
      cancelHistory.current = true;
    }
    function onKey(event: KeyboardEvent) {
      if (event.key === 'Escape') {
        if (busyRef.current) return;
        event.preventDefault();
        setConfirmError(null);
        setConfirm(null);
        return;
      }
      if (event.key !== 'Tab' || !cancelDialogRef.current) return;
      const items = [...cancelDialogRef.current.querySelectorAll<HTMLElement>('button:not([disabled])')];
      if (items.length === 0) return;
      const first = items[0];
      const last = items[items.length - 1];
      if (event.shiftKey && document.activeElement === first) {
        event.preventDefault();
        last.focus();
      } else if (!event.shiftKey && document.activeElement === last) {
        event.preventDefault();
        first.focus();
      }
    }
    function onPop() {
      if (cancelLeaving.current) return;
      if (busyRef.current) {
        window.history.pushState({ cancelDeliveryDialog: true }, '');
        return;
      }
      setConfirmError(null);
      setConfirm(null);
    }
    document.addEventListener('keydown', onKey);
    window.addEventListener('popstate', onPop);
    return () => {
      document.removeEventListener('keydown', onKey);
      window.removeEventListener('popstate', onPop);
    };
  }, [confirm]);

  useEffect(() => {
    const riderOpen = confirm !== null && confirm !== 'cancel' && confirm !== 'delete';
    if (!riderOpen) {
      if (riderHistory.current) {
        riderHistory.current = false;
        chooseTriggerRef.current?.focus();
        if (window.history.state?.chooseRiderDialog === true) window.history.back();
      }
      return undefined;
    }
    keepComparingRef.current?.focus();
    if (!riderHistory.current) {
      window.history.pushState({ chooseRiderDialog: true }, '');
      riderHistory.current = true;
    }
    function onKey(event: KeyboardEvent) {
      if (event.key === 'Escape') {
        if (busyRef.current) return;
        event.preventDefault();
        setConfirmError(null);
        setConfirm(null);
        return;
      }
      if (event.key !== 'Tab' || !riderDialogRef.current) return;
      const items = [...riderDialogRef.current.querySelectorAll<HTMLElement>('button:not([disabled])')];
      if (items.length === 0) return;
      const first = items[0];
      const last = items[items.length - 1];
      if (event.shiftKey && document.activeElement === first) {
        event.preventDefault();
        last.focus();
      } else if (!event.shiftKey && document.activeElement === last) {
        event.preventDefault();
        first.focus();
      }
    }
    function onPop() {
      if (busyRef.current) {
        window.history.pushState({ chooseRiderDialog: true }, '');
        return;
      }
      setConfirmError(null);
      setConfirm(null);
    }
    document.addEventListener('keydown', onKey);
    window.addEventListener('popstate', onPop);
    return () => {
      document.removeEventListener('keydown', onKey);
      window.removeEventListener('popstate', onPop);
    };
  }, [confirm]);

  useEffect(() => {
    if (!decline) {
      if (declineHistory.current) {
        declineHistory.current = false;
        declineTriggerRef.current?.focus();
        if (window.history.state?.declineOfferDialog === true) window.history.back();
      }
      return undefined;
    }
    keepOfferRef.current?.focus();
    if (!declineHistory.current) {
      window.history.pushState({ declineOfferDialog: true }, '');
      declineHistory.current = true;
    }
    function onKey(event: KeyboardEvent) {
      if (event.key === 'Escape') {
        if (busyRef.current) return;
        event.preventDefault();
        setDeclineError(null);
        setDecline(null);
        return;
      }
      if (event.key !== 'Tab' || !declineDialogRef.current) return;
      const items = [...declineDialogRef.current.querySelectorAll<HTMLElement>('button:not([disabled])')];
      if (items.length === 0) return;
      const first = items[0];
      const last = items[items.length - 1];
      if (event.shiftKey && document.activeElement === first) {
        event.preventDefault();
        last.focus();
      } else if (!event.shiftKey && document.activeElement === last) {
        event.preventDefault();
        first.focus();
      }
    }
    function onPop() {
      if (busyRef.current) {
        window.history.pushState({ declineOfferDialog: true }, '');
        return;
      }
      setDeclineError(null);
      setDecline(null);
    }
    document.addEventListener('keydown', onKey);
    window.addEventListener('popstate', onPop);
    return () => {
      document.removeEventListener('keydown', onKey);
      window.removeEventListener('popstate', onPop);
    };
  }, [decline]);

  useEffect(() => {
    let stopped = false;
    async function load() {
      if (document.visibilityState === 'hidden') return;
      const current = latest.current;
      if (current && !shouldPollDelivery(current) && !showsRiderOffers(current)) return;
      const token = await accessToken();
      if (stopped) return;
      if (!token) {
        setToken(null);
        setError('Delivery details are unavailable.');
        setIsLoading(false);
        setDetailsRetrying(false);
        setOffersRetrying(false);
        return;
      }
      setToken(token);
      try {
        const loaded = await loadDelivery(token, id);
        if (stopped) return;
        setNow(Date.now());
        latest.current = loaded;
        setDelivery(loaded);
        setError(null);
        if (showsRiderOffers(loaded)) {
          try {
            const bids = await loadOffers(token, id);
            if (!stopped) {
              const open = activeCustomerBids(bids, dismissedOffers.current);
              const ids = open.map((bid) => bid.id);
              if (offersMissingSince(seenOffers.current, ids)) setOfferNotice('An offer is no longer available.');
              seenOffers.current = ids;
              setOffers(open);
              setOffersError(null);
              setOffersLoaded(true);
            }
          } catch (caught) {
            if (!stopped) {
              setOffers((current) => withoutBidMapPoints(current));
              setOffersError(deliveryErrorMessage(caught, 'Offers are unavailable.'));
              setOffersLoaded(true);
            }
          }
        } else if (!stopped) {
          setOffers([]);
          seenOffers.current = [];
          setOffersLoaded(true);
          setOffersError(null);
          setOfferNotice(null);
        }
        if (!stopped && showsCompletedRoute(loaded)) {
          const line = await loadDeliveryRoute(token, id).catch(() => []);
          if (!stopped) setRouteLine(line);
        }
      } catch (caught) {
        if (!stopped && !latest.current) setError(deliveryErrorMessage(caught, 'Delivery details are unavailable.'));
      } finally {
        if (!stopped) {
          setIsLoading(false);
          setDetailsRetrying(false);
          setOffersRetrying(false);
        }
      }
    }
    const hold = retryHold.current;
    retryHold.current = null;
    if (hold !== 'offers') {
      latest.current = null;
      seenOffers.current = [];
      if (dismissedDeliveryId.current !== id) {
        dismissedDeliveryId.current = id;
        dismissedOffers.current = new Set();
      }
      setOfferNotice(null);
      setDelivery(null);
      setIsLoading(true);
    }
    void load();
    const poll = window.setInterval(() => {
      if (document.visibilityState === 'hidden') return;
      setNow(Date.now());
      void load();
    }, TRACKING_POLL_MS);
    const onVisible = () => {
      if (document.visibilityState === 'visible') { setNow(Date.now()); void load(); }
    };
    document.addEventListener('visibilitychange', onVisible);
    return () => {
      stopped = true;
      window.clearInterval(poll);
      document.removeEventListener('visibilitychange', onVisible);
    };
  }, [accessToken, attempt, id]);

  const nearbyPickup = delivery && showsRiderOffers(delivery) && delivery.pickupLatitude !== null && delivery.pickupLongitude !== null
    ? `${delivery.pickupLatitude},${delivery.pickupLongitude}`
    : null;
  useEffect(() => {
    if (!nearbyPickup) return undefined;
    const [latitude, longitude] = nearbyPickup.split(',').map(Number);
    let stopped = false;
    let pending = false;
    const hidden = () => document.visibilityState === 'hidden';
    async function loadNearby() {
      if (stopped || pending || hidden()) return;
      pending = true;
      try {
        const token = await accessToken();
        if (!token || stopped || hidden()) return;
        const result = await fetchNearbyRiders(token, latitude, longitude);
        if (!stopped) setNearby(result.points);
      } catch {
        if (!stopped) setNearby([]);
      } finally {
        pending = false;
      }
    }
    void loadNearby();
    const timer = window.setInterval(() => { void loadNearby(); }, 20_000);
    const onVisible = () => {
      if (document.visibilityState === 'visible') void loadNearby();
    };
    document.addEventListener('visibilitychange', onVisible);
    return () => {
      stopped = true;
      window.clearInterval(timer);
      document.removeEventListener('visibilitychange', onVisible);
    };
  }, [accessToken, nearbyPickup]);

  useEffect(() => {
    if (nearby.length === 0) return undefined;
    const timer = window.setInterval(() => {
      const now = new Date();
      setNearby((current) => {
        const next = filterValidNearbyRiderPoints(current, now);
        return next.length === current.length ? current : next;
      });
    }, NEARBY_MARKER_PRUNE_MS);
    return () => window.clearInterval(timer);
  }, [nearby.length]);

  const responseSeconds = delivery ? offerResponseSeconds(delivery, now) : null;
  const cooldownSeconds = delivery ? routeCooldownSeconds(delivery, now) : 0;
  const responseElapsed = responseSeconds === 0;
  // Offers and delivery details share this route. Hold a clean expiry screen
  // until the authoritative outcome arrives and the message has been visible.
  const expiryKey = delivery?.offerResponseExpiresAt
    ? `${delivery.id}:${delivery.offerResponseExpiresAt}` : null;
  const [expiryNotice, setExpiryNotice] = useState<{ key: string; until: number } | null>(null);
  const [expiryNoticeElapsed, setExpiryNoticeElapsed] = useState<string | null>(null);
  const observedOfferKey = useRef<string | null>(null);
  const expiredOutcome = delivery?.status === 'NO_RIDER_FOUND' && delivery.offerResponseExpired;
  const showExpiryTrigger = !!expiryKey && (
    responseElapsed || (expiredOutcome && observedOfferKey.current === expiryKey)
  );
  useEffect(() => {
    if (delivery && showsRiderOffers(delivery) && expiryKey) {
      observedOfferKey.current = expiryKey;
    }
    if (!showExpiryTrigger || !expiryKey) return;
    setExpiryNotice((previous) => previous?.key === expiryKey
      ? previous : { key: expiryKey, until: Date.now() + 2000 });
    setConfirm(null);
    setDecline(null);
    setSortOpen(false);
    setParcelOpen(false);
    setPriceOpen(false);
  }, [delivery, expiryKey, showExpiryTrigger]);
  useEffect(() => {
    if (!expiryNotice) return;
    const timer = window.setTimeout(() => setExpiryNoticeElapsed(expiryNotice.key),
      Math.max(0, expiryNotice.until - Date.now()));
    return () => window.clearTimeout(timer);
  }, [expiryNotice]);
  const showExpiryNotice = !!expiryKey && (
    responseElapsed ||
    (expiredOutcome && (showExpiryTrigger || expiryNotice?.key === expiryKey)
      && expiryNoticeElapsed !== expiryKey)
  );
  const trackingClock = delivery !== null && (keepsRiderLocation(delivery.status) || responseSeconds !== null || cooldownSeconds > 0 || (delivery.status === 'CREATED' && offers.length === 0));
  useEffect(() => {
    if (!responseElapsed && !delivery?.offerResponseExpired) return;
    if (busy) return;
    setConfirm((current) => current && current !== 'cancel' && current !== 'delete' ? null : current);
    setDecline(null);
  }, [responseElapsed, delivery?.offerResponseExpired, busy]);
  useEffect(() => {
    if (!trackingClock) return undefined;
    const timer = window.setInterval(() => {
      if (document.visibilityState === 'visible') setNow(Date.now());
    }, 1000);
    return () => window.clearInterval(timer);
  }, [trackingClock]);

  const confirmSnapshot = useRef(confirm);
  if (confirm) confirmSnapshot.current = confirm;
  const shownConfirm = confirm ?? confirmSnapshot.current;
  const riderSnapshot = useRef<CustomerBid | null>(null);
  if (confirm !== null && confirm !== 'cancel' && confirm !== 'delete') riderSnapshot.current = confirm;
  const shownRider = confirm !== null && confirm !== 'cancel' && confirm !== 'delete' ? confirm : riderSnapshot.current;
  const requestDialog = confirm === 'cancel';
  const riderDialog = confirm !== null && confirm !== 'cancel' && confirm !== 'delete';
  const declineSnapshot = useRef<CustomerBid | null>(null);
  if (decline) declineSnapshot.current = decline;
  const shownDecline = decline ?? declineSnapshot.current;
  const sheetConfirm = confirm === 'delete';
  const parcelMotion = usePresence(parcelOpen, 220);
  const sortMotion = usePresence(sortOpen, 220);
  const priceMotion = usePresence(priceOpen, 220);
  const requestMotion = usePresence(requestDialog, 150);
  const riderMotion = usePresence(riderDialog, 150);
  const declineMotion = usePresence(decline !== null, 150);
  const confirmMotion = usePresence(sheetConfirm, 150);
  const view = detailViewState({ isLoading, error, hasDelivery: delivery !== null });
  if (view === 'loading' && !detailsRetrying) {
    return (
      <div className="track page-stage is-entering">
        <div className="track-loading">
          <TopSpinner active label="Loading delivery" />
          <p aria-hidden="true">Loading delivery</p>
        </div>
      </div>
    );
  }
  if (view === 'error' || !delivery) {
    return (
      <div className="track page-stage is-entering">
        <Link className="fullscreen-back" to="/deliveries" aria-label="Back">
          <BackIcon />
        </Link>
        <ErrorMessage>{error ?? 'Delivery details are unavailable.'}</ErrorMessage>
        <Button type="button" variant="secondary" size="compact" disabled={detailsRetrying} onClick={() => { if (retryHold.current || detailsRetrying) return; retryHold.current = 'details'; setDetailsRetrying(true); setAttempt((value) => value + 1); }}>{detailsRetrying ? <><ButtonSpinner />{pageActionFeedback('retry', true)?.label}</> : 'Try again'}</Button>
      </div>
    );
  }

  if (showExpiryNotice) {
    return (
      <div className="track track-plain page-stage is-entering">
        <section className="offer-expiry-screen" role="status" aria-live="polite">
          <span className="offer-expiry-icon" aria-hidden="true">
            <svg width="36" height="36" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.8" strokeLinecap="round" strokeLinejoin="round">
              <circle cx="12" cy="12" r="9" />
              <path d="M12 7v5l3 2" />
            </svg>
          </span>
          <h1>Offer expired</h1>
          <p>You did not choose a rider in time.</p>
        </section>
      </div>
    );
  }

  const screen = deliveryScreen(delivery);
  const orderedOffers = sortRiderOffers(offers, offerSort);
  // The existing API exposes the request creation time, not a dedicated search
  // deadline. Preserve the start of a retry locally so its clock doesn't restart
  // when this screen is reopened in the same browser.
  const searchStarted = (() => {
    const stored = window.localStorage.getItem(`riders:search-start:${delivery.id}`);
    const retried = stored ? Number(stored) : NaN;
    const created = delivery.createdAt ? Date.parse(delivery.createdAt) : NaN;
    return Number.isFinite(retried) && retried >= created ? retried : created;
  })();
  const searchSeconds = Number.isFinite(searchStarted)
    ? Math.max(0, Math.ceil((searchStarted + 6 * 60_000 - now) / 1000))
    : null;
  const showSearchTimer = screen === 'offers' && offersLoaded && orderedOffers.length === 0
    && searchSeconds !== null && searchSeconds > 0;
  const actions = deliveryActions(delivery, now);
  const mapView = trackingMapView(delivery, now);
  const live = mapView.kind === 'live';
  const showsMap = showsCompletedRoute(delivery)
    || showsDeliveredDestination(delivery)
    || (screen === 'offers' && delivery.pickupLatitude !== null && delivery.pickupLongitude !== null)
    || (screen !== 'outcome' && mapView.kind !== 'hidden');
  const approach = live ? delivery.pickupApproach : null;
  const straightMetres = live ? activeStopStraightLineMetres(delivery, now) : null;
  const arrived = withinArrival(straightMetres);
  const headline = trackingHeadline(delivery.status, straightMetres);
  const subtitle = trackingSubtitle(headline, delivery.dropoffAddress);
  const summary = pickupDistanceTag(straightMetres, approach?.metres, approach?.seconds);
  const currentDelivery = delivery;

  function openPrice() {
    if (busyRef.current) return;
    setPriceText(currentDelivery.customerOffer ?? currentDelivery.suggestedPrice);
    setPriceError(null);
    setPriceOpen(true);
  }

  async function savePrice() {
    const submitted = customerOfferForBooking(priceText);
    if ('error' in submitted) {
      setPriceError(submitted.error);
      return;
    }
    if (busyRef.current) return;
    busyRef.current = true;
    setBusy(true);
    setPriceError(null);
    try {
      const sessionToken = await accessToken();
      if (!sessionToken) throw new Error('Sign in again.');
      await adjustOffer(sessionToken, currentDelivery.id, submitted.offeredPrice);
      try {
        setDelivery(await loadDelivery(sessionToken, currentDelivery.id));
      } catch {
        setPriceError('Your price was saved, but this delivery could not be refreshed.');
        return;
      }
      setPriceOpen(false);
    } catch (caught) {
      setPriceError(deliveryErrorMessage(caught, 'This offer could not be saved.'));
    } finally {
      busyRef.current = false;
      setBusy(false);
    }
  }

  async function cancelRequest() {
    if (busyRef.current) return;
    busyRef.current = true;
    setBusy(true);
    setConfirmError(null);
    const request = showsRiderOffers(currentDelivery);
    try {
      const sessionToken = await accessToken();
      if (!sessionToken) throw new Error('Sign in again.');
      await cancelDelivery(sessionToken, currentDelivery.id);
      showSuccessToast(deliveryCancelledToast(currentDelivery.id));
      cancelLeaving.current = true;
      cancelHistory.current = false;
      if (window.history.state?.cancelDeliveryDialog === true) {
        await new Promise<void>((resolve) => {
          window.addEventListener('popstate', () => resolve(), { once: true });
          window.history.back();
        });
      }
      beginPageTransition(() => navigate('/deliveries', { replace: true }));
    } catch (caught) {
      setConfirmError(deliveryErrorMessage(caught, request ? 'This request could not be cancelled.' : 'This action could not be completed.'));
    } finally {
      busyRef.current = false;
      setBusy(false);
    }
  }

  async function deleteRequest() {
    if (busyRef.current) return;
    busyRef.current = true;
    setBusy(true);
    setConfirmError(null);
    try {
      const sessionToken = await accessToken();
      if (!sessionToken) throw new Error('Sign in again.');
      await cancelDelivery(sessionToken, currentDelivery.id);
      beginPageTransition(() => navigate('/deliveries', { replace: true }));
    } catch (caught) {
      setConfirmError(deliveryErrorMessage(caught, 'This delivery could not be deleted.'));
    } finally {
      busyRef.current = false;
      setBusy(false);
    }
  }

  async function confirmRider(bid: CustomerBid) {
    if (busyRef.current) return;
    const current = latest.current;
    if (!current || !showsRiderOffers(current) || offerResponseSeconds(current, Date.now()) === 0) {
      setConfirm(null);
      return;
    }
    const started = accepting.current.begin();
    const blocked = duplicateAcceptanceNotice(started);
    if (blocked) {
      setConfirmError(blocked);
      return;
    }
    busyRef.current = true;
    setBusy(true);
    setConfirmError(null);
    try {
      const sessionToken = await accessToken();
      if (!sessionToken) throw new Error('Sign in again.');
      if (offerResponseSeconds(currentDelivery, Date.now()) === 0) throw new Error('The offer response window has ended.');
      const key = acceptanceKeyFor(sessionStorage, currentDelivery.id, bid.id, () => crypto.randomUUID());
      let accepted;
      try {
        accepted = await acceptOffer(sessionToken, currentDelivery.id, bid.id, key);
      } catch (caught) {
        if (!keepsAcceptanceKey(caught)) throw caught;
        const latestDelivery = await loadDelivery(sessionToken, currentDelivery.id);
        if (latestDelivery.status !== 'RIDER_ASSIGNED' && latestDelivery.status !== 'COLLECTING') throw caught;
        clearAcceptanceKey(sessionStorage, currentDelivery.id, bid.id);
        setDelivery(latestDelivery);
        showSuccessToast(riderConfirmedToast(latestDelivery.id));
        setConfirm(null);
        return;
      }
      if (accepted.deliveryId !== currentDelivery.id || accepted.bidId !== bid.id) {
        throw new Error('This offer could not be accepted.');
      }
      clearAcceptanceKey(sessionStorage, currentDelivery.id, bid.id);
      setDelivery((current) => current ? { ...current, status: 'RIDER_ASSIGNED', offeredPrice: accepted.acceptedBidAmount, riderLocation: null } : current);
      const next = await loadDelivery(sessionToken, currentDelivery.id).catch(() => null);
      if (next) setDelivery(next);
      showSuccessToast(riderConfirmedToast(currentDelivery.id));
      setConfirm(null);
    } catch (caught) {
      setConfirmError(deliveryErrorMessage(caught, 'This offer could not be accepted.'));
    } finally {
      accepting.current.end();
      busyRef.current = false;
      setBusy(false);
    }
  }

  async function declineOffer(bid: CustomerBid) {
    if (!currentDelivery || busyRef.current) return;
    busyRef.current = true;
    setBusy(true);
    setDeclineError(null);
    try {
      const sessionToken = await accessToken();
      if (!sessionToken) throw new Error('Sign in again.');
      await dismissOffer(sessionToken, currentDelivery.id, bid.id);
      dismissedOffers.current.add(bid.id);
      seenOffers.current = seenOffers.current.filter((item) => item !== bid.id);
      setOffers((current) => activeCustomerBids(current, dismissedOffers.current));
      try {
        const bids = await loadOffers(sessionToken, currentDelivery.id);
        const open = activeCustomerBids(bids, dismissedOffers.current);
        seenOffers.current = open.map((item) => item.id);
        setOffers(open);
      } catch {
        // The declined offer is already removed from the list.
      }
      setDecline(null);
    } catch (caught) {
      setDeclineError(deliveryErrorMessage(caught, 'This offer could not be declined.'));
    } finally {
      busyRef.current = false;
      setBusy(false);
    }
  }

  async function searchAgain() {
    if (routeCooldownSeconds(currentDelivery, Date.now()) > 0) return;
    if (busyRef.current) return;
    busyRef.current = true;
    setBusy(true);
    setSearching(true);
    setActionError(null);
    try {
      const sessionToken = await accessToken();
      if (!sessionToken) throw new Error('Sign in again.');
      await searchForRider(sessionToken, currentDelivery.id);
      window.localStorage.setItem(`riders:search-start:${currentDelivery.id}`, String(Date.now()));
      try {
        const next = await loadDelivery(sessionToken, currentDelivery.id);
        dismissedOffers.current = new Set();
        seenOffers.current = [];
        setOffers([]);
        setOffersLoaded(false);
        setOfferNotice(null);
        setNow(Date.now());
        latest.current = next;
        setDelivery(next);
        setAttempt((value) => value + 1);
      } catch {
        setActionError('The search started, but this delivery could not be refreshed.');
        return;
      }
    } catch (caught) {
      setActionError(deliveryErrorMessage(caught, 'The search could not be started.'));
    } finally {
      busyRef.current = false;
      setBusy(false);
      setSearching(false);
    }
  }

  return (
    <div className={screen === 'tracking' ? 'track track-live page-stage is-entering' : showsMap ? 'track page-stage is-entering' : 'track track-plain page-stage is-entering'}>
      {showsMap ? null : <div className="track-wash" aria-hidden="true" />}
      <Link className="fullscreen-back" to="/deliveries" aria-label="Back">
        <BackIcon />
      </Link>
      {showsCompletedRoute(delivery) ? (
        <TrackingMap
          deliveryId={delivery.id}
          live={false}
          rider={storedRiderPoint(delivery)}
          stop={{ latitude: delivery.dropoffLatitude ?? 0, longitude: delivery.dropoffLongitude ?? 0 }}
          pickup={{ latitude: delivery.pickupLatitude ?? 0, longitude: delivery.pickupLongitude ?? 0 }}
          headingToDropoff
          line={routeLine.length > 1 ? routeLine : [
            { latitude: delivery.pickupLatitude ?? 0, longitude: delivery.pickupLongitude ?? 0 },
            { latitude: delivery.dropoffLatitude ?? 0, longitude: delivery.dropoffLongitude ?? 0 },
          ]}
          summary={null}
          stroke="#1A73E8"
        />
      ) : null}
      {showsDeliveredDestination(delivery) ? (
        <TrackingMap
          deliveryId={delivery.id}
          live={false}
          rider={null}
          stop={{ latitude: delivery.dropoffLatitude ?? 0, longitude: delivery.dropoffLongitude ?? 0 }}
          headingToDropoff
          line={[]}
          summary={null}
          deliveredCallout={{
            name: delivery.recipientName?.trim() ?? '',
            address: deliveryCardAddress(delivery.dropoffAddress),
            when: delivery.completedAt ? deliveryWhenLabel(delivery.completedAt) : '',
          }}
        />
      ) : null}
      {screen === 'offers' && delivery.pickupLatitude !== null && delivery.pickupLongitude !== null ? (
        <TrackingMap
          deliveryId={delivery.id}
          live={false}
          rider={null}
          stop={{ latitude: delivery.pickupLatitude, longitude: delivery.pickupLongitude }}
          headingToDropoff={false}
          line={[]}
          summary={null}
          extraMarkers={[
            ...offerMapMarkers(orderedOffers),
            ...filterValidNearbyRiderPoints(nearby).map((point) => ({ id: point.id, latitude: point.latitude, longitude: point.longitude, title: 'Available rider' })),
          ]}
          neighborhood
          interactive={false}
          pickupLabel="Pickup location"
        />
      ) : null}
      {screen !== 'outcome' && mapView.kind !== 'hidden' ? (
        <TrackingMap
          deliveryId={mapView.deliveryId}
          live={live}
          rider={riderMarkerForMap(mapView)}
          stop={mapView.stop}
          headingToDropoff={mapView.headingToDropoff}
          pickupLabel={!mapView.headingToDropoff ? 'Pickup location' : null}
          line={approach?.line ?? []}
          hideRoute={arrived}
          summary={summary}
          stroke="#1A73E8"
        />
      ) : null}
      {screen === 'status' ? (
        <section className="status-band" aria-label="Delivery status">
          <div className="status-hero">
            <span className="status-hero-icon" aria-hidden="true">{delivery.status === 'ASSIGNED' ? <BikeMark /> : <ContentMark kind="parcel" />}</span>
            <h1>{statusBandCopy(delivery.status).title}</h1>
            <p>{statusBandCopy(delivery.status).support}</p>
          </div>
          <DeliveryFacts delivery={delivery} showContacts />
        </section>
      ) : null}
      {screen === 'status' ? null : <section className={screen === 'offers' ? 'track-sheet track-offers-sheet' : 'track-sheet'} aria-label="Delivery details">
        {screen === 'offers' ? <div className="offers-handle" aria-hidden="true" /> : null}
        {screen === 'outcome' && delivery.status === 'DELIVERED' ? (
          <DeliveredSummary delivery={delivery} />
        ) : screen === 'outcome' ? (
          <OutcomeSummary
            delivery={delivery}
            accessToken={token}
            onParcel={() => setParcelOpen(true)}
            onAdjust={openPrice}
          />
        ) : (
          <>
            {screen !== 'offers' && delivery.serviceClass === 'EXPRESS' ? <p className="track-kicker">Urgent</p> : null}
            <div className="track-title-row">
              <h1>{screen === 'offers' ? activeOfferCountLabel(offers.length) : (headline ?? customerListStatusLabel(delivery, now))}</h1>
              {live ? <p className="track-live-pill">Live</p> : null}
              {showSearchTimer ? (
                <span className="offer-search-countdown" role="timer" aria-label="Rider search time remaining">
                  {offerResponseLabel(searchSeconds ?? 0)}
                </span>
              ) : null}
              {screen === 'offers' && orderedOffers.length > 0 ? (
                <button type="button" className="offer-sort" aria-label={`Sort offers, ${offerSortLabel(offerSort)}`} onClick={() => setSortOpen(true)}>
                  <SwapIcon />
                  <span>{offerSortShortLabel(offerSort)}</span>
                  <ChevronDown />
                </button>
              ) : null}
            </div>
            {subtitle ? <p>{subtitle}</p> : null}
            {screen === 'tracking' && deadlineLabel(delivery.deliverBy) ? <p className="track-note">Deliver by {deadlineLabel(delivery.deliverBy)}</p> : null}
            {screen === 'tracking' && !delivery.offeredPrice ? <p className="track-note">Riders offer their own price. This suggestion is not the agreed price.</p> : null}
          </>
        )}
        {screen !== 'outcome' && delivery.rider && headline ? (
          <div className="track-rider">
            <RiderPhoto
              tile
              name={delivery.rider.name}
              hasProfilePhoto={delivery.rider.hasProfilePhoto}
              path={delivery.rider.hasProfilePhoto ? `/customers/me/deliveries/${encodeURIComponent(delivery.id)}/rider-profile-photo` : null}
              accessToken={token}
            />
            <div>
              <strong>{delivery.rider.name}</strong>
              {riderBikeLine(delivery.rider.motorcycle, delivery.rider.registrationNumber) ? <p>{riderBikeLine(delivery.rider.motorcycle, delivery.rider.registrationNumber)}</p> : null}
              {delivery.rider.colour ? <p>{delivery.rider.colour}</p> : null}
            </div>
            {actions.contact ? (
              <ContactLinks
                phone={delivery.rider.phone}
                callLabel={`Call ${delivery.rider.name}`}
                whatsAppLabel={`WhatsApp ${delivery.rider.name}`}
              />
            ) : null}
          </div>
        ) : null}
        {screen === 'offers' ? (
          <div className="track-offers">
            {responseSeconds !== null ? (
              <div className={`offer-response-timer${responseSeconds <= 60 ? ' is-urgent' : ''}`}>
                <span>{responseElapsed ? 'Response time ended' : 'Choose a rider before time runs out'}</span>
                <strong role="timer" aria-label="Time remaining">{offerResponseLabel(responseSeconds)}</strong>
              </div>
            ) : null}
            {responseElapsed ? <p className="track-meta" role="status">Waiting for the server to confirm expiry…</p> : null}
            {offerNotice ? <p className="track-meta">{offerNotice}</p> : null}
            {!offersLoaded && orderedOffers.length === 0 ? (
              <div className="offer-skeletons" role="status" aria-label="Loading offers">
                <span />
                <span />
              </div>
            ) : null}
            {offersError ? <ErrorMessage>{offersError}</ErrorMessage> : null}
            {offersLoaded && offersError && orderedOffers.length === 0 ? (
              <Button type="button" variant="secondary" size="compact" disabled={offersRetrying} onClick={() => { if (retryHold.current || offersRetrying) return; retryHold.current = 'offers'; setOffersRetrying(true); setAttempt((value) => value + 1); }}>{offersRetrying ? <><ButtonSpinner />{pageActionFeedback('retry', true)?.label}</> : 'Retry'}</Button>
            ) : null}
            {offersLoaded && !offersError && orderedOffers.length === 0 ? (
              <div className="offers-empty">
                <div className="offers-check" aria-hidden="true"><SearchIcon /></div>
                <h2>Looking for your rider</h2>
                <p>Your request is live. Offers will appear here as riders respond.</p>
              </div>
            ) : null}
            {orderedOffers.map((bid) => {
              const rating = riderRatingLine(bid);
              const canAccept = bidCanAccept(bid);
              return (
              <article key={bid.id}>
                <div className="offer-identity">
                <RiderPhoto
                  tile
                  name={bid.riderName}
                  hasProfilePhoto={bid.hasProfilePhoto}
                  path={bid.hasProfilePhoto ? `/customers/me/deliveries/${encodeURIComponent(delivery.id)}/bids/${encodeURIComponent(bid.id)}/profile-photo` : null}
                  accessToken={token}
                />
                <div className="offer-copy">
                  <div className="offer-name-row">
                    <strong>{offerRiderName(bid.riderName)}</strong>
                    <span className={`offer-class offer-class-${bid.riderClass.toLowerCase()}`}>{riderClassLabel(bid.riderClass)}</span>
                  </div>
                  <p className="offer-rating-row">
                    <span className="offer-star" aria-hidden="true">★</span>
                    {rating.rating ? <span className="offer-rating">{rating.rating}</span> : null}
                    {rating.rating ? <span aria-hidden="true">·</span> : null}
                    <span>{rating.rides}</span>
                  </p>
                  <p className={`offer-eta-line${pickupEtaLabel(bid.pickupEtaSeconds) === 'ETA unavailable' ? ' is-unavailable' : ''}`}>
                    {pickupEtaLabel(bid.pickupEtaSeconds) === 'ETA unavailable' ? 'ETA unavailable' : `${pickupEtaLabel(bid.pickupEtaSeconds)} away`}
                  </p>
                </div>
                <div className="offer-price">
                  <span>{moneyLabel(bid.currency, bid.amount)}</span>
                </div>
                </div>
                {canAccept ? (
                <div className="offer-actions">
                  <Button type="button" variant="tertiary" size="compact" disabled={busy || responseElapsed} onClick={(event) => { if (busy || responseElapsed) return; setDeclineError(null); declineTriggerRef.current = event.currentTarget; setDecline(bid); }}>{busy && decline?.id === bid.id ? <><ButtonSpinner />{pageActionFeedback('decline', true)?.label}</> : 'Decline'}</Button>
                  <Button type="button" size="compact" disabled={busy || responseElapsed} onClick={(event) => { if (busy || responseElapsed) return; setConfirmError(null); chooseTriggerRef.current = event.currentTarget; setConfirm(bid); }}>{busy && typeof confirm === 'object' && confirm?.id === bid.id ? <><ButtonSpinner />{pageActionFeedback('choose', true)?.label}</> : 'Choose Rider'}</Button>
                </div>
                ) : <p>This offer is no longer available.</p>}
              </article>
              );
            })}
          </div>
        ) : null}
        <div className={screen === 'outcome' ? 'outcome-actions' : screen === 'tracking' || screen === 'offers' ? 'track-actions track-footer' : 'track-actions'}>
          {actions.cancel || actions.offers ? <Button ref={cancelTriggerRef} type="button" variant="tertiary" size="compact" className="track-cancel-text" disabled={busy} onClick={() => { if (busyRef.current) return; setConfirmError(null); setConfirm('cancel'); }}>{busy && confirm === 'cancel' ? <><ButtonSpinner />{pageActionFeedback('cancel', true)?.label}</> : actions.offers ? 'Cancel request' : 'Cancel delivery'}</Button> : null}
          {actions.searchAgain && cooldownSeconds > 0 ? <div className="offer-response-timer"><span>You can search again in</span><strong role="timer">{offerResponseLabel(cooldownSeconds)}</strong></div> : null}
          {actions.searchAgain ? <Button type="button" disabled={searchAgainControl({ searching, busy, coolingDown: cooldownSeconds > 0 }).disabled} onClick={() => void searchAgain()}>{searching ? <><ButtonSpinner />{pageActionFeedback('search', true)?.label}</> : <><SearchIcon />Search again</>}</Button> : null}
          {actions.deleteRequest ? <Button type="button" variant="destructive" disabled={busy} onClick={() => { if (busyRef.current) return; setConfirmError(null); setConfirm('delete'); }}>{busy && confirm === 'delete' ? <><ButtonSpinner />{pageActionFeedback('delete', true)?.label}</> : 'Delete'}</Button> : null}
          {actions.adjustPrice && screen !== 'outcome' ? <button type="button" disabled={busy} onClick={openPrice}>Adjust price</button> : null}
          {actions.parcel && screen !== 'outcome' ? <button type="button" className="track-parcel" onClick={() => setParcelOpen(true)}>Parcel details<ChevronUp /></button> : null}
        </div>
        {actionError ? <ErrorMessage>{actionError}</ErrorMessage> : null}
      </section>}
      {parcelMotion.mounted ? (
        <div className={motionClass('deliveries-sheet-backdrop', 'sheet', parcelMotion.visible)} onClick={() => setParcelOpen(false)}>
          <div className="deliveries-sheet" role="dialog" aria-label="Parcel details" onClick={(event) => event.stopPropagation()}>
            <div className="parcel-sheet-head">
              <h2>Parcel details</h2>
            </div>
            <DeliveryFacts delivery={delivery} showContacts />
          </div>
        </div>
      ) : null}
      {requestMotion.mounted ? (
        <CancelDeliveryDialog
          request={showsRiderOffers(delivery)}
          busy={busy}
          error={confirmError}
          visible={requestMotion.visible}
          dialogRef={cancelDialogRef}
          keepRef={keepRequestRef}
          onDismiss={() => { if (busy) return; setConfirmError(null); setConfirm(null); }}
          onConfirm={() => void cancelRequest()}
        />
      ) : null}
      {riderMotion.mounted && shownRider ? (
        <div className={motionClass('confirm-dialog-backdrop', 'dialog', riderMotion.visible)} onClick={() => { if (busy) return; setConfirmError(null); setConfirm(null); }}>
          <div
            ref={riderDialogRef}
            className="confirm-dialog"
            role="dialog"
            aria-modal="true"
            aria-labelledby="choose-rider-title"
            aria-describedby="choose-rider-copy"
            aria-busy={busy}
            onClick={(event) => event.stopPropagation()}
          >
            <h2 id="choose-rider-title">Choose rider?</h2>
            <p id="choose-rider-copy">Confirm {shownRider.riderName} as your rider for {moneyLabel(shownRider.currency, shownRider.amount)}?</p>
            {confirmError ? <ErrorMessage>{confirmError}</ErrorMessage> : null}
            <div className="confirm-dialog-actions">
              <button ref={keepComparingRef} type="button" className="confirm-keep confirm-dismiss" disabled={busy} onClick={() => { if (busy) return; setConfirmError(null); setConfirm(null); }}>Keep comparing</button>
              <button type="button" className="confirm-accept" disabled={busy || responseElapsed || !showsRiderOffers(delivery)} onClick={() => void confirmRider(shownRider)}>{busy ? modalActionFeedback('choose', true)?.label : 'Confirm rider'}</button>
            </div>
          </div>
        </div>
      ) : null}
      {declineMotion.mounted && shownDecline ? (
        <div className={motionClass('confirm-dialog-backdrop', 'dialog', declineMotion.visible)} onClick={() => { if (busy) return; setDeclineError(null); setDecline(null); }}>
          <div
            ref={declineDialogRef}
            className="confirm-dialog"
            role="dialog"
            aria-modal="true"
            aria-labelledby="decline-offer-title"
            aria-describedby="decline-offer-copy"
            aria-busy={busy}
            onClick={(event) => event.stopPropagation()}
          >
            <h2 id="decline-offer-title">Decline this offer?</h2>
            <p id="decline-offer-copy">Are you sure you want to decline {offerRiderName(shownDecline.riderName)}&apos;s offer?</p>
            {declineError ? <ErrorMessage>{declineError}</ErrorMessage> : null}
            <div className="confirm-dialog-actions">
              <button ref={keepOfferRef} type="button" className="confirm-keep confirm-dismiss" disabled={busy} onClick={() => { if (busy) return; setDeclineError(null); setDecline(null); }}>Keep offer</button>
              <button type="button" className="confirm-decline" disabled={busy} onClick={() => void declineOffer(shownDecline)}>{busy ? modalActionFeedback('decline', true)?.label : 'Decline offer'}</button>
            </div>
          </div>
        </div>
      ) : null}
      {confirmMotion.mounted && shownConfirm === 'delete' ? (
        <div className={motionClass('confirm-dialog-backdrop', 'dialog', confirmMotion.visible)} onClick={() => { if (busy) return; setConfirmError(null); setConfirm(null); }}>
          <div className="confirm-dialog" role="dialog" aria-modal="true" aria-labelledby="delete-delivery-title" aria-describedby="delete-delivery-copy" onClick={(event) => event.stopPropagation()}>
            <h2 id="delete-delivery-title">Delete this delivery?</h2>
            <p id="delete-delivery-copy">This cannot be undone.</p>
            {confirmError ? <ErrorMessage>{confirmError}</ErrorMessage> : null}
            <div className="confirm-dialog-actions">
              <button type="button" className="confirm-keep confirm-dismiss" disabled={busy} onClick={() => { if (busy) return; setConfirmError(null); setConfirm(null); }}>Cancel</button>
              <button type="button" className="confirm-cancel" disabled={busy} onClick={() => void deleteRequest()}>{busy ? modalActionFeedback('delete', true)?.label : 'Delete'}</button>
            </div>
          </div>
        </div>
      ) : null}
      {sortMotion.mounted ? (
        <div className={motionClass('deliveries-sheet-backdrop', 'sheet', sortMotion.visible)} onClick={() => setSortOpen(false)}>
          <div className="deliveries-sheet" role="dialog" aria-label="Sort by" onClick={(event) => event.stopPropagation()}>
            <h2>Sort by</h2>
            {([
              ['price', 'Price: lowest to highest', false],
              ['price-high', 'Price: highest to lowest', true],
              ['rides-low', 'Rides: lowest to highest', false],
              ['rides-high', 'Rides: highest to lowest', true],
            ] as const).map(([id, label, descending]) => (
              <button key={id} type="button" className={offerSort === id ? 'sort-option is-selected' : 'sort-option'} onClick={() => { setOfferSort(id); setSortOpen(false); }}>
                <SortIcon descending={descending} />
                {label}
                <span className="sort-radio">{offerSort === id ? <CheckMark /> : null}</span>
              </button>
            ))}
          </div>
        </div>
      ) : null}
      {priceMotion.mounted ? (
        <div className={motionClass('deliveries-sheet-backdrop', 'sheet', priceMotion.visible)} onClick={() => { if (busy) return; setPriceOpen(false); }}>
          <div className="deliveries-sheet price-sheet" role="dialog" aria-modal="true" aria-labelledby="adjust-price-title" onClick={(event) => event.stopPropagation()}>
            <h2 id="adjust-price-title">Your offer ({delivery.currency === 'ZWG' ? 'ZiG' : 'USD'})</h2>
            <label className="book-offer">
              <span className="book-offer-field">
                <span aria-hidden="true">{delivery.currency === 'ZWG' ? 'ZiG' : 'USD'}</span>
                <input inputMode="decimal" maxLength={7} value={priceText} onChange={(event) => { setPriceText(offerFieldText(event.target.value)); setPriceError(null); }} />
              </span>
            </label>
            {priceError ? <ErrorMessage>{priceError}</ErrorMessage> : null}
            <div className="price-sheet-actions">
              <button type="button" className="price-sheet-cancel confirm-dismiss" disabled={busy} onClick={() => setPriceOpen(false)}>Cancel</button>
              <button type="button" className="price-sheet-save confirm-accept" disabled={busy} onClick={() => void savePrice()}>{busy ? modalActionFeedback('save', true)?.label : 'Save price'}</button>
            </div>
          </div>
        </div>
      ) : null}
    </div>
  );
}

function CancelDeliveryDialog({
  request,
  busy,
  error,
  visible,
  dialogRef,
  keepRef,
  onDismiss,
  onConfirm,
}: {
  request: boolean;
  busy: boolean;
  error: string | null;
  visible: boolean;
  dialogRef: RefObject<HTMLDivElement | null>;
  keepRef: RefObject<HTMLButtonElement | null>;
  onDismiss: () => void;
  onConfirm: () => void;
}) {
  const title = request ? 'Cancel this request?' : 'Cancel delivery?';
  const copy = request ? 'We will stop looking for a rider.' : 'Cancelling closes this delivery request.';
  const keep = request ? 'Keep request' : 'Keep delivery';
  const confirm = request ? 'Cancel request' : 'Cancel delivery';
  return (
    <div className={motionClass('confirm-dialog-backdrop', 'dialog', visible)} onClick={onDismiss}>
      <div
        ref={dialogRef}
        className="confirm-dialog"
        role="dialog"
        aria-modal="true"
        aria-labelledby="cancel-delivery-title"
        aria-describedby="cancel-delivery-copy"
        aria-busy={busy}
        onClick={(event) => event.stopPropagation()}
      >
        <h2 id="cancel-delivery-title">{title}</h2>
        <p id="cancel-delivery-copy">{copy}</p>
        {error ? <ErrorMessage>{error}</ErrorMessage> : null}
        <div className="confirm-dialog-actions">
          <button ref={keepRef} type="button" className="confirm-keep confirm-dismiss" disabled={busy} onClick={onDismiss}>{keep}</button>
          <button type="button" className="confirm-cancel" disabled={busy} onClick={onConfirm}>{busy ? modalActionFeedback('cancel', true)?.label : confirm}</button>
        </div>
      </div>
    </div>
  );
}

function storedRiderPoint(delivery: CustomerDeliveryDetail): RoutePoint | null {
  const point = delivery.riderLocation;
  if (!point) return null;
  return { latitude: point.latitude, longitude: point.longitude };
}

function OutcomeSummary({
  delivery,
  accessToken,
  onParcel,
  onAdjust,
}: {
  delivery: CustomerDeliveryDetail;
  accessToken: string | null;
  onParcel: () => void;
  onAdjust: () => void;
}) {
  const tone = deliveryStatusTone(delivery.status);
  const rider = outcomeShowsRider(delivery.status) ? delivery.rider : null;
  const inTransit = deliveryOutcomeTitle(delivery.status) === 'In transit';
  const customerOffer = delivery.status === 'NO_RIDER_FOUND';
  const cancelled = delivery.status === 'CANCELLED' ? cancelledDeliveryCopy(delivery.cancellation) : null;
  const reference = shortDeliveryReference(delivery.id).replace(/^#/, '');
  return (
    <div className="outcome">
      <div className="outcome-status">
        <span className={customerOffer ? 'outcome-icon outcome-icon-no-rider' : 'outcome-icon'} style={customerOffer ? undefined : { background: tone.background, color: tone.color }} aria-hidden="true">
          <StatusGlyph status={delivery.status} />
        </span>
        <h1 style={{ color: tone.color, fontWeight: delivery.status === 'CANCELLED' ? 500 : 700 }}>{cancelled ? cancelled.title : delivery.offerResponseExpired ? 'Request expired' : deliveryOutcomeTitle(delivery.status)}</h1>
        <p>{cancelled ? cancelled.support : delivery.offerResponseExpired ? 'You did not choose a rider in time. Search again to receive new offers.' : deliveryOutcomeSupport(delivery.status)}</p>
      </div>
      {cancelled?.bookAgain ? (
        <Button to="/book" state={{ rebook: bookingDraftFromDelivery(delivery) }}>Book another rider</Button>
      ) : null}
      {cancelled?.contactSupport ? (
        <div className="support-row">
          <p>Contact support about this parcel.</p>
          <ContactLinks phone={SUPPORT_PHONE} message={`Hello, my rider cancelled delivery #${reference} after collecting the parcel.`} callLabel="Call support" whatsAppLabel="WhatsApp support" />
        </div>
      ) : null}
      {rider ? (
        <div className="track-rider">
          <RiderPhoto
            tile
            name={rider.name}
            hasProfilePhoto={rider.hasProfilePhoto}
            path={rider.hasProfilePhoto ? `/customers/me/deliveries/${encodeURIComponent(delivery.id)}/rider-profile-photo` : null}
            accessToken={accessToken}
          />
          <div>
            <strong>{rider.name}</strong>
            {rider.motorcycle ? <p>{rider.motorcycle}</p> : null}
          </div>
          {riderDialUrl(rider.phone) ? (
            <ContactLinks phone={rider.phone} callLabel={`Call ${rider.name}`} whatsAppLabel={`WhatsApp ${rider.name}`} />
          ) : null}
        </div>
      ) : null}
      {inTransit ? (
        <button type="button" className="outcome-parcel" onClick={onParcel}>Parcel details<ChevronUp /></button>
      ) : (
        <DeliveryFacts delivery={delivery} showContacts customerOffer={customerOffer} onAdjust={customerOffer ? onAdjust : undefined} />
      )}
    </div>
  );
}

function DeliveredSummary({ delivery }: { delivery: CustomerDeliveryDetail }) {
  const kind = deliveryContentKind(delivery.parcelDescription);
  const when = delivery.createdAt ? deliveryWhenLabel(delivery.createdAt) : '';
  const amount = (delivery.offeredPrice?.trim() || delivery.suggestedPrice).trim();
  const reference = shortDeliveryReference(delivery.id).replace(/^#/, '');
  const message = `Hello, I have a question or complaint about delivery #${reference}.`;
  return (
    <div className="delivered-summary">
      <div className="facts-badge">
        <DeliveryLabels kind={kind} serviceClass={delivery.serviceClass} />
      </div>
      <div className="delivery-facts">
        {when ? <p><span>Requested</span><strong>{when}</strong></p> : null}
        <p><span>Delivery</span><strong>{shortDeliveryReference(delivery.id)}</strong></p>
      </div>
      <p className="delivery-stop"><PinMark dropoff={false} />{stopCopy(delivery.senderName, delivery.pickupAddress)}</p>
      <p className="delivery-stop"><PinMark dropoff />{stopCopy(delivery.recipientName, delivery.dropoffAddress)}</p>
      <div className="delivery-facts delivery-price">
        <p><span>Distance</span><strong>{deliveryDistanceLabel(delivery.distanceMeters)}</strong></p>
        <p className="facts-price">
          <span className="price-label">Price</span>
          <strong>
            {amount ? moneyLabel(delivery.currency, amount) : 'Unavailable'}
            <PaymentBadge method={delivery.paymentMethod} />
          </strong>
        </p>
      </div>
      <div className="support-row">
        <p>Questions or complaints?</p>
        <ContactLinks phone={SUPPORT_PHONE} message={message} callLabel="Call support" whatsAppLabel="WhatsApp support" />
      </div>
    </div>
  );
}

function stopCopy(name: string | null | undefined, address: string) {
  const place = deliveryCardAddress(address);
  const contact = name?.trim();
  if (!contact) return <span>{place}</span>;
  return (
    <span className="delivery-stop-copy">
      <strong>{contact}</strong>
      <span>{place}</span>
    </span>
  );
}

function DeliveryFacts({
  delivery,
  showContacts = false,
  customerOffer = false,
  onAdjust,
}: {
  delivery: CustomerDeliveryDetail;
  showContacts?: boolean;
  customerOffer?: boolean;
  onAdjust?: () => void;
}) {
  const when = delivery.createdAt ? deliveryWhenLabel(delivery.createdAt) : '';
  const amount = customerOffer
    ? (delivery.customerOffer?.trim() || delivery.suggestedPrice)
    : (delivery.offeredPrice ?? delivery.suggestedPrice);
  const kind = deliveryContentKind(delivery.parcelDescription);
  return (
    <div className="delivery-facts-card">
      <div className="facts-badge">
        <DeliveryLabels kind={kind} serviceClass={delivery.serviceClass} />
        <strong>{shortDeliveryReference(delivery.id)}</strong>
      </div>
      {when ? <p className="facts-date"><CalendarMark />{when}</p> : null}
      <p className="delivery-stop"><PinMark dropoff={false} />{stopCopy(showContacts ? delivery.senderName : null, delivery.pickupAddress)}</p>
      <p className="delivery-stop"><PinMark dropoff />{stopCopy(showContacts ? delivery.recipientName : null, delivery.dropoffAddress)}</p>
      <div className={`delivery-facts${onAdjust ? ' delivery-facts-editable' : ''}`}>
        <p><span>Distance</span><strong>{deliveryDistanceLabel(delivery.distanceMeters)}</strong></p>
        <p className="facts-price">
          <span className="price-label">{customerOffer ? 'Your offer' : 'Price'}</span>
          <strong>
            <span className="facts-price-amount">{moneyLabel(delivery.currency, amount)}</span>
            <PaymentBadge method={delivery.paymentMethod} />
            {onAdjust ? (
              <button type="button" className="facts-adjust-icon" onClick={onAdjust} aria-label="Adjust price" title="Adjust price">
                <svg viewBox="0 0 24 24" aria-hidden="true" fill="none" stroke="currentColor" strokeWidth="1.8" strokeLinecap="round" strokeLinejoin="round">
                  <path d="M16.5 3.5a2.12 2.12 0 0 1 3 3L9 17l-4 1 1-4L16.5 3.5Z" />
                </svg>
              </button>
            ) : null}
          </strong>
        </p>
      </div>
    </div>
  );
}

function StatusGlyph({ status }: { status: CustomerDeliveryDetail['status'] }) {
  if (status === 'NO_RIDER_FOUND') {
    return <svg viewBox="0 0 24 24"><path d="M12 20a8 8 0 1 0-8-8 8 8 0 0 0 8 8m0-18a10 10 0 1 1-10 10A10 10 0 0 1 12 2m.5 5v5.25l4.5 2.67-.75 1.23L11 13V7h1.5Z" /></svg>;
  }
  if (status === 'DELIVERED') {
    return <svg viewBox="0 0 24 24"><path d="M21 7 9 19l-5.5-5.5 1.41-1.41L9 16.17 19.59 5.59 21 7Z" /></svg>;
  }
  if (status === 'CANCELLED') {
    return <svg viewBox="0 0 24 24"><path d="M19 6.41 17.59 5 12 10.59 6.41 5 5 6.41 10.59 12 5 17.59 6.41 19 12 13.41 17.59 19 19 17.59 13.41 12 19 6.41Z" /></svg>;
  }
  if (status === 'FAILED') {
    return <svg viewBox="0 0 24 24"><path d="M11 15h2v2h-2v-2m0-8h2v6h-2V7m1-5a10 10 0 1 0 10 10A10 10 0 0 0 12 2m0 18a8 8 0 1 1 8-8 8 8 0 0 1-8 8Z" /></svg>;
  }
  return <svg viewBox="0 0 24 24"><path d="M12 2 2 7v10l10 5 10-5V7L12 2Zm0 2.2 7.2 3.8L12 11.8 4.8 8 12 4.2ZM4 9.4l7 3.6v7.1l-7-3.6V9.4Zm9 10.7v-7.1l7-3.6v7.1l-7 3.6Z" /></svg>;
}

function BikeMark() {
  return <svg viewBox="0 0 24 24"><path d="M19 7a2 2 0 0 0-2-2h-3v2h3v2.65L13.52 14H10V9H6a4 4 0 0 0-4 4v3h2a3 3 0 0 0 6 0h4.48L19 10.35V7M7 17a1 1 0 0 1-1-1h2a1 1 0 0 1-1 1m12-4a3 3 0 1 0 3 3 3 3 0 0 0-3-3m0 4a1 1 0 1 1 1-1 1 1 0 0 1-1 1Z" /></svg>;
}

function CalendarMark() {
  return <svg viewBox="0 0 24 24"><path d="M19 19H5V8h14m-3-7v2H8V1H6v2H5a2 2 0 0 0-2 2v14a2 2 0 0 0 2 2h14a2 2 0 0 0 2-2V5a2 2 0 0 0-2-2h-1V1m1 11h-5v5h5v-5Z" /></svg>;
}

function PinMark({ dropoff }: { dropoff: boolean }) {
  return (
    <svg viewBox="4 1 16 22" aria-hidden="true" style={{ color: dropoff ? '#1A73E8' : '#169B62' }}>
      <path fill={dropoff ? '#1A73E8' : '#169B62'} d="M12 2.2a6.2 6.2 0 0 0-6.2 6.2c0 4.2 6.2 10.2 6.2 10.2s6.2-6 6.2-10.2A6.2 6.2 0 0 0 12 2.2z" /><text x="12" y="11.7" textAnchor="middle" fontSize="8.5" fontWeight="700" fill="#ffffff">{dropoff ? '2' : '1'}</text>
    </svg>
  );
}

function SearchIcon() {
  return <svg className="outcome-search-icon" viewBox="0 0 24 24" aria-hidden="true"><path d="M9.5 3A6.5 6.5 0 0 1 16 9.5c0 1.61-.59 3.09-1.56 4.23l.27.27h.79l5 5-1.5 1.5-5-5v-.79l-.27-.27A6.52 6.52 0 0 1 9.5 16 6.5 6.5 0 0 1 3 9.5 6.5 6.5 0 0 1 9.5 3m0 2A4.5 4.5 0 1 0 14 9.5 4.5 4.5 0 0 0 9.5 5Z" fill="currentColor" /></svg>;
}

function ChevronUp() {
  return <svg viewBox="0 0 24 24" aria-hidden="true"><path d="M7.41 15.41 12 10.83l4.59 4.58L18 14l-6-6-6 6 1.41 1.41Z" fill="currentColor" /></svg>;
}

function ChevronDown() {
  return <svg viewBox="0 0 24 24" aria-hidden="true"><path d="M7.41 8.59 12 13.17l4.59-4.58L18 10l-6 6-6-6 1.41-1.41Z" fill="currentColor" /></svg>;
}

function SwapIcon() {
  return <svg viewBox="0 0 24 24" aria-hidden="true"><path d="M9 3 5 7h3v10H5l4 4 4-4h-3V7h3L9 3m6 0-4 4h3v10h-3l4 4 4-4h-3V7h3l-4-4Z" fill="currentColor" /></svg>;
}

function SortIcon({ descending }: { descending: boolean }) {
  return descending
    ? <svg viewBox="0 0 24 24" aria-hidden="true"><path d="M19 7h3L18 3l-4 4h3v14h2M11 13H9v8H7v-8H5l4-4 4 4H11Z" fill="currentColor" /></svg>
    : <svg viewBox="0 0 24 24" aria-hidden="true"><path d="M19 17h3l-4 4-4-4h3V3h2M11 13H9V3H7v10H5l4 4 4-4H11Z" fill="currentColor" /></svg>;
}



function CheckMark() {
  return <svg viewBox="0 0 24 24" aria-hidden="true"><path d="M21 7 9 19l-5.5-5.5 1.41-1.41L9 16.17 19.59 5.59 21 7Z" fill="currentColor" /></svg>;
}

function ContactLinks({
  phone,
  message,
  callLabel,
  whatsAppLabel,
}: {
  phone: string | null;
  message?: string;
  callLabel: string;
  whatsAppLabel: string;
}) {
  const call = riderDialUrl(phone);
  const chat = riderWhatsAppUrl(phone);
  if (!call || !chat) return null;
  const whatsApp = message ? `${chat}?text=${encodeURIComponent(message)}` : chat;
  return (
    <div className="track-contact">
      <a className="track-icon-btn" href={call} aria-label={callLabel}><span className="material-symbols-outlined" aria-hidden="true">call</span></a>
      <a className="track-icon-btn" href={whatsApp} aria-label={whatsAppLabel}><WhatsAppIcon /></a>
    </div>
  );
}

function WhatsAppIcon() {
  return (
    <svg className="whatsapp-icon" viewBox="0 0 24 24" aria-hidden="true">
      <path className="whatsapp-outline" d="M20.5 11.6a8.5 8.5 0 0 1-12.4 7.5L3 20.5l1.4-5A8.5 8.5 0 1 1 20.5 11.6Z" fill="none" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round" />
      <path d="M8.2 7.4c-.3-.4-.6-.4-.9-.3-.6.2-1.1.9-1.1 1.7 0 2.4 3.2 5.9 6.1 7.2 1.7.8 3.3.8 4.1 0 .5-.5.7-1.1.6-1.5-.1-.2-.3-.3-.5-.4l-2.1-1c-.3-.1-.5-.1-.7.2l-.8 1c-1.7-.8-3-2.1-3.9-3.8l.9-.9c.2-.2.2-.5.1-.7Z" fill="currentColor" stroke="none" />
    </svg>
  );
}

function deadlineLabel(value: string | null): string | null {
  if (!value) return null;
  const deadline = new Date(value);
  if (Number.isNaN(deadline.getTime())) return null;
  const months = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'];
  const hours = String(deadline.getHours()).padStart(2, '0');
  const minutes = String(deadline.getMinutes()).padStart(2, '0');
  return `${deadline.getDate()} ${months[deadline.getMonth()]} ${deadline.getFullYear()}, ${hours}:${minutes}`;
}

function offerSortLabel(sort: OfferSort): string {
  if (sort === 'price-high') return 'Price: highest to lowest';
  if (sort === 'rides-low') return 'Rides: lowest to highest';
  if (sort === 'rides-high') return 'Rides: highest to lowest';
  return 'Price: lowest to highest';
}

function offerSortShortLabel(sort: OfferSort): string {
  return sort === 'rides-low' || sort === 'rides-high' ? 'Rides' : 'Price';
}

const SUPPORT_PHONE = '+263772569226';
