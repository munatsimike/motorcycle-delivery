import { useEffect, useRef, useState } from 'react';
import addressBookImage from '../assets/address-book.png';
import { Link, useNavigate } from 'react-router-dom';
import { deleteSavedAddress, listSavedAddresses } from '../booking/addressApi';
import { AddressAvatar } from '../booking/AddressAvatar';
import { AddressSearchField, AddressSearchToggle } from '../booking/AddressSearchField';
import { AddressTypeFilter, type AddressTypeChoice } from '../booking/AddressTypeFilter';
import {
  emptyAddressList,
  filterSavedAddresses,
  readSavedAddresses,
  savedAddressLabel,
  withoutSavedAddress,
  type SavedAddress,
} from '../booking/savedAddress';
import { isSessionRejection } from '../auth/contracts';
import { rememberReturnPath } from '../auth/returnPath';
import { useSession } from '../auth/sessionContext';
import { modalActionFeedback } from '../components/buttonState';
import { AddIcon, BackIcon } from '../components/icons';
import { ErrorMessage } from '../components/ErrorMessage';
import { Loading } from '../components/Loading';
import { deliveryErrorMessage } from '../deliveries/api';
import { beginPageTransition } from '../motion/pageTransition';
import { motionClass, usePresence } from '../motion/usePresence';

export function AddressesPage() {
  const navigate = useNavigate();
  const { accessToken, signOut } = useSession();
  const [addresses, setAddresses] = useState<SavedAddress[]>([]);
  const [search, setSearch] = useState('');
  const [searchOpen, setSearchOpen] = useState(false);
  const [addressType, setAddressType] = useState<AddressTypeChoice>('ALL');
  const [fabCompact, setFabCompact] = useState(false);
  const scrollRef = useRef<HTMLDivElement>(null);
  const matchingAddresses = filterSavedAddresses(addresses, search).filter((entry) => addressType === 'ALL' || entry.label === addressType);
  const [error, setError] = useState<string | null>(null);
  const [loading, setLoading] = useState(true);
  const [pendingDelete, setPendingDelete] = useState<SavedAddress | null>(null);
  const [deleting, setDeleting] = useState(false);
  const dialog = usePresence(pendingDelete !== null, 150);

  useEffect(() => {
    let active = true;
    void accessToken().then(async (token) => {
      if (!active) return;
      if (!token) {
        rememberReturnPath('/addresses');
        navigate('/sign-in', { replace: true, state: { from: '/addresses' } });
        return;
      }
      try {
        const rows = readSavedAddresses(await listSavedAddresses(token));
        if (active) setAddresses(rows);
      } catch (caught) {
        if (!active) return;
        if (isSessionRejection(caught)) {
          rememberReturnPath('/addresses');
          await signOut();
          navigate('/sign-in', { replace: true, state: { from: '/addresses' } });
          return;
        }
        setError(deliveryErrorMessage(caught, 'Saved addresses are unavailable.'));
      } finally {
        if (active) setLoading(false);
      }
    }).catch(() => {
      if (active) {
        setError('Saved addresses are unavailable.');
        setLoading(false);
      }
    });
    return () => { active = false; };
  }, [accessToken, navigate, signOut]);

  useEffect(() => {
    const node = scrollRef.current;
    if (!node) return undefined;
    let last = node.scrollTop;
    const onScroll = () => {
      const next = node.scrollTop;
      if (next <= 8 || next < last - 4) setFabCompact(false);
      else if (next > last + 4) setFabCompact(true);
      last = next;
    };
    node.addEventListener('scroll', onScroll, { passive: true });
    return () => node.removeEventListener('scroll', onScroll);
  }, [loading, addresses.length]);

  async function remove(entry: SavedAddress) {
    if (deleting) return;
    setDeleting(true);
    setError(null);
    try {
      const token = await accessToken();
      if (!token) throw new Error('Saved addresses are unavailable.');
      await deleteSavedAddress(token, entry.id);
      setAddresses((current) => withoutSavedAddress(current, entry.id));
      setPendingDelete(null);
    } catch (caught) {
      setError(deliveryErrorMessage(caught, 'The address could not be deleted.'));
      setPendingDelete(null);
    } finally {
      setDeleting(false);
    }
  }

  return (
    <section className="book address-book-page page-stage is-entering">
      <header className="book-header">
        <button type="button" className="book-back" aria-label="Back" onClick={() => beginPageTransition(() => navigate('/profile'))}>
          <BackIcon />
        </button>
        <h1>Address Book</h1>
      </header>
      {!loading && addresses.length > 0 ? (
        <div className={searchOpen ? 'address-book-toolbar is-searching' : 'address-book-toolbar'}>
          {searchOpen ? <AddressSearchField value={search} onChange={setSearch} onDismiss={() => { setSearchOpen(false); setSearch(''); }} /> : <AddressSearchToggle expanded={searchOpen} onToggle={() => setSearchOpen(true)} />}
          {!searchOpen ? <AddressTypeFilter value={addressType} onChange={setAddressType} /> : null}
        </div>
      ) : null}
      <div className="book-scroll" ref={scrollRef}>
        <div className="book-column address-book">
          {loading ? <Loading label="Loading addresses" /> : null}
          {!loading && emptyAddressList(addresses) ? (
            <div className="address-empty">
              <img src={addressBookImage} alt="" />
              <Link className="address-add" to="/addresses/new">Add address</Link>
              <h2>No address saved yet</h2>
              <p>Saved addresses will appear here.</p>
            </div>
          ) : null}
          {!loading && addresses.length > 0 && matchingAddresses.length === 0 ? <p className="address-search-empty">No matching addresses.</p> : null}
          {matchingAddresses.map((entry, index) => (
            <article key={entry.id} className={index === 0 ? 'address-card is-first' : 'address-card'}>
              <AddressAvatar name={entry.contactName} />
              <div className="address-card-heading">
                <h2>{entry.contactName}</h2>
                <span className={`address-type-badge ${entry.label === 'WORK' ? 'is-work' : 'is-home'}`}>{savedAddressLabel(entry)}</span>
              </div>
              <p className="address-card-location">{entry.address}</p>
              <div className="address-card-footer">
                <p className="address-card-phone">{entry.contactPhone}</p>
                <div className="address-card-actions">
                <Link className="address-icon-action" to={`/addresses/${entry.id}`} aria-label={`Edit ${savedAddressLabel(entry)} address`} title="Edit address">
                  <svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.8" strokeLinecap="round" strokeLinejoin="round" aria-hidden="true">
                    <path d="M16.5 3.5a2.12 2.12 0 0 1 3 3L9 17l-4 1 1-4Z" />
                  </svg>
                </Link>
                <button className="address-icon-action address-icon-delete" type="button" aria-label={`Delete ${savedAddressLabel(entry)} address`} title="Delete address" onClick={() => setPendingDelete(entry)}>
                  <svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.8" strokeLinecap="round" strokeLinejoin="round" aria-hidden="true">
                    <path d="M3 6h18M8 6V4h8v2m3 0-1 14H6L5 6m5 4v7m4-7v7" />
                  </svg>
                </button>
                </div>
              </div>
            </article>
          ))}
          {error ? <ErrorMessage>{error}</ErrorMessage> : null}
        </div>
      </div>
      {!loading && addresses.length > 0 && !searchOpen ? (
        <Link className={fabCompact ? 'address-book-fab is-compact' : 'address-book-fab'} to="/addresses/new" aria-label="Add address">
          <AddIcon />
          <span>Add</span>
        </Link>
      ) : null}
      {dialog.mounted && pendingDelete ? (
        <div className={motionClass('confirm-dialog-backdrop', 'dialog', dialog.visible)} onClick={(event) => { if (event.target === event.currentTarget && !deleting) setPendingDelete(null); }}>
          <div className="confirm-dialog" role="dialog" aria-modal="true" aria-labelledby="delete-address-title" aria-describedby="delete-address-copy" onClick={(event) => event.stopPropagation()}>
            <h2 id="delete-address-title">Delete address?</h2>
            <p id="delete-address-copy">Are you sure you want to remove this address?</p>
            <div className="confirm-dialog-actions">
              <button type="button" className="confirm-keep confirm-dismiss" disabled={deleting} onClick={() => setPendingDelete(null)}>Cancel</button>
              <button className="confirm-cancel" type="button" disabled={deleting} onClick={() => { void remove(pendingDelete); }}>{deleting ? modalActionFeedback('delete', true)?.label : 'Delete address'}</button>
            </div>
          </div>
        </div>
      ) : null}
    </section>
  );
}
